<p align="center"><a href="https://t.me/RICKTHON"><img src="https://telegra.ph/file/7a15378b69199ca46c072.jpg" width="5000"></a></p>
<h1 align="center"><b>RICKTHON_USERBOT 🇮🇶 </b></h1>
<h4 align="center">𓆰♥️🧸 𝐖𝐞𝐥𝐂𝐨𝐦𝐞 𝑻𝐨 𝙎𝙊𝙐𝙍𝘾𝞝_𝐑𝐈𝐂𝐊𝐓𝐇𝐎𝐍↷.</h4>

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FRallsthon%2FRalls&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false)](https://github.com/Rallsthon/Ralls)
[![Open Source](https://badges.frapsoft.com/os/v2/open-source.png?v=103)](https://github.com/ellerbrock/open-source-badges/)
[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green?&style=flat-square)](https://GitHub.com/Rallsthon/Ralls/graphs/commit-activity) 
![Repo Size](https://img.shields.io/github/repo-size/sandy1709/catuserbot?&style=flat-square&logo=github)


# String Session - Telethon 🖱
### Repl 🧨
[![Run on Repl.it](https://repl.it/badge/github/STARKGANG/friday)](https://replit.com/@taabn-tabantaba/CodeTelethon-1?v=1)
- Get your `API_ID` and `API_HASH` from [here](https://my.telegram.org/)    

### Deploying To Heroku ⚙
[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/rick1128/rickthoniq)

# Licence 📋
[![GNU GPLv3 Image](https://www.gnu.org/graphics/gplv3-127x51.png)](http://www.gnu.org/licenses/gpl-3.0.en.html)  

* Copyright (C) 2020-2021 by Repthon@Github, < https://github.com/rick1128 >.

RallsUserbot is Free Software: You can use, study share and improve it at your
will. Specifically you can redistribute and/or modify it under the terms of the
[GNU General Public License](https://www.gnu.org/licenses/gpl.html) as
published by the Free Software Foundation, either version 3 of the License, or
(at your option) any later version. 

  
## Dev
   <a href="https://t.me/ZQ_LO"><img src="https://img.shields.io/badge/Source%20Dev%3F-here-inactive?&style=plastic?&logo=telegram" width=220px></a></p>
✗ ¦ ↱SAIF↲ ¦ ✗ 𐇮
.
