from jepthon import BOTLOG, BOTLOG_CHATID, jepiq
from JepIQ.razan.resources.assistant import *
from ..Config import Config
from ..core.inlinebot import *
