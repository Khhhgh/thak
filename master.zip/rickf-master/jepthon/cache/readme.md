To store cache file of JepThon
