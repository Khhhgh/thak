#edit  ~ @lMl10l for jepiq 

from telethon import events
from jepthon.utils import admin_cmd
from jepthon import jepiq
from . import *
 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

plugin_category = "extra"
@jepiq.ar_cmd(
    pattern="س1$",
    command=("س1", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    lMl10l = await reply_id(event)
    if sad:
        jepiq = f"**˛rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        jepiq += f"✛━━━━━━━━━━━━━✛\n"
        jepiq += f"**الـمتحـرڪـة الأولـى **"
        await event.client.send_file(event.chat_id, sad, caption=jepiq, reply_to=lMl10l)

#edit  ~ @lMl10l for jepiq 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jepiq.ar_cmd(
    pattern="س2$",
    command=("س2", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    leo = await reply_id(event)
    if sad2:
        RAZAN = f"**˛Rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـثـانيـة **"
        await event.client.send_file(event.chat_id, sad2, caption=RAZAN, reply_to=leo)

#edit  ~ @lMl10l for jepiq 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jepiq.ar_cmd(
    pattern="س3$",
    command=("س3", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    sic_id = await reply_id(event)
    if sad3:
        RAZAN = f"**˛Rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـثـالثـة**\n"
        await event.client.send_file(event.chat_id, sad3, caption=RAZAN, reply_to=sic_id)

#edit  ~ @lMl10l for jepiq 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jepiq.ar_cmd(
    pattern="س4$",
    command=("س4", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad4:
        RAZAN = f"** ˛rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـرابـعـة**\n"
        await event.client.send_file(
            event.chat_id, sad4, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @lMl10l for jepiq 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jepiq.ar_cmd(
    pattern="س5$",
    command=("س5", plugin_category),
           )

async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad5:
        RAZAN = f"** ˛rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـخامسـة**\n"
        await event.client.send_file(
            event.chat_id, sad5, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @lMl10l for jepiq 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jepiq.ar_cmd(
    pattern="س6$",
    command=("س6", plugin_category),
           )

async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad6:
        RAZAN = f"** ˛rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـسادسـة**\n"
        await event.client.send_file(
            event.chat_id, sad6, caption=RAZAN, reply_to=reply_to_id
        )

#edit  ~ @lMl10l for jepiq 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك

@jepiq.ar_cmd(
    pattern="س7$",
    command=("س7", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad7:
        RAZAN = f"** ˛rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الـسـابعـة**\n"
        await event.client.send_file(
            event.chat_id, sad7, caption=RAZAN, reply_to=reply_to_id
        )
      
      
@jepiq.ar_cmd(
    pattern="س8$",
    command=("س8", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad8:
        RAZAN = f"** ˛rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة الثـامنـة**\n"
        await event.client.send_file(
            event.chat_id, sad8, caption=RAZAN, reply_to=reply_to_id
        )

@jepiq.ar_cmd(
    pattern="س9$",
    command=("س9", plugin_category),
           )
async def tmgif(event):
    if event.fwd_from:
        return
    reply_to_id = await reply_id(event)
    if sad9:
        RAZAN = f"** ˛rick ، ٰ𝖦𝗂𝖿 𝖲ِ𝖺ٰ𝖣 . .**\n"
        RAZAN += f"✛━━━━━━━━━━━━━✛\n"
        RAZAN += f"**الـمتحـرڪـة التـاسعـة**\n"
        await event.client.send_file(
            event.chat_id, sad9, caption=RAZAN, reply_to=reply_to_id
        )
#edit  ~ @lMl10l for jepiq 
#جميع الحقوق محفوظة لسـورس جـيبثون تخـمط تبيـن فشلـك
